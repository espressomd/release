#!/bin/sh

cd `dirname $0`

autoreconf -iv -Wall
autoreconf -fv -Wall
