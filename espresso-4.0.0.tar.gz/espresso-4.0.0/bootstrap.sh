#!/bin/bash

echo The autotools-based build system has been removed. Please use cmake instead.
echo See the user\'s guide for instructions.

